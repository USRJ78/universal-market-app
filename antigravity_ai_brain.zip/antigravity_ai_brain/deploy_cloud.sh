#!/bin/bash
# deploy_cloud.sh - Deploy Antigravity AI Brain on Linux VPS

set -e

echo "=================================================="
echo "   ANTIGRAVITY AI BRAIN CLOUD DEPLOYMENT SETUP"
echo "=================================================="

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "[INFO] Docker not found. Installing Docker..."
    sudo apt-get update
    sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    sudo apt-get update
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io
    sudo usermod -aG docker $USER
    echo "[SUCCESS] Docker installed successfully."
else
    echo "[INFO] Docker is already installed."
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo "[INFO] Installing Docker Compose..."
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.24.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    echo "[SUCCESS] Docker Compose installed."
else
    echo "[INFO] Docker Compose is already installed."
fi

# Create .env template if not exists
if [ ! -f .env ]; then
    echo "[INFO] Creating .env file template..."
    cat <<EOT > .env
# Antigravity AI Brain Credentials Config
GEMINI_API_KEY=your_gemini_api_key_here
DELTA_API_KEY=your_delta_api_key_here
DELTA_API_SECRET=your_delta_api_secret_here
EOT
    echo "[WARN] Created .env template. PLEASE EDIT .env AND SPECIFY YOUR API KEYS BEFORE RUNNING COMPOSER!"
else
    echo "[INFO] .env file already exists."
fi

# Build and start container
echo "[INFO] Starting container in background..."
docker compose up -d --build

echo "=================================================="
echo "[SUCCESS] Deployment initialized successfully!"
echo "- To check logs: docker compose logs -f"
echo "- To stop daemon: docker compose down"
echo "=================================================="
