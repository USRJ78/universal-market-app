# trading_desk.py
import ccxt
import time
import os
import sys
from datetime import datetime

# Ensure UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')

DEMO_API = "qsNKMuPZyeubUK7rpqligKksNO0tey"
DEMO_SECRET = "jjMmELW0NEENLvkHqVTCx6iQNJNzFI8EFeLkY7V7lb3NVfmteX4iOUE5ClNH"
ENDPOINT = "https://cdn-ind.testnet.deltaex.org"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(BASE_DIR, "ai_brain.log")

def log_message(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted = f"[{timestamp}] [DESK] {msg}"
    print(formatted)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(formatted + "\n")
    except Exception:
        pass

class TradingDesk:
    def __init__(self, use_sandbox=False):
        self.use_sandbox = use_sandbox
        
        # Load API keys from environment variables first, fall back to Demo Testnet keys
        self.api_key = os.environ.get("DELTA_API_KEY", DEMO_API)
        self.api_secret = os.environ.get("DELTA_API_SECRET", DEMO_SECRET)
        
        if os.environ.get("DELTA_API_KEY") and os.environ.get("DELTA_API_SECRET"):
            log_message("Loading Delta API credentials from environment variables.")
        else:
            log_message("Environment keys missing/incomplete. Using default Testnet Demo keys.")
            
        self.exchange = ccxt.delta({
            'apiKey': self.api_key,
            'secret': self.api_secret,
            'enableRateLimit': True
        })
        self.exchange.urls['api'] = {
            'public': ENDPOINT,
            'private': ENDPOINT
        }
        
    def check_connection(self):
        """Checks authentication and whitelisting. Configures sandbox mode if blocked."""
        if self.use_sandbox:
            log_message("Running in virtual sandbox mode.")
            return True
            
        try:
            self.exchange.load_markets()
            bal = self.exchange.fetch_balance()
            free_usd = bal.get('USD', {}).get('free', 0.0)
            log_message(f"Live connection established. Margin wallet: {free_usd:.2f} USD")
            return True
        except Exception as e:
            log_message(f"[ERROR] Critical connection failed: {e}. Exiting program.")
            sys.exit(f"Critical: Live connection failed: {e}")

    def get_wallet_balance(self):
        if self.use_sandbox:
            return 1000.0 # Virtual balance
        try:
            bal = self.exchange.fetch_balance()
            return float(bal.get('USD', {}).get('free', 0.0))
        except Exception as e:
            log_message(f"[ERROR] Failed to fetch wallet balance: {e}. Raising exception.")
            raise RuntimeError(f"Failed to fetch balance: {e}")

    def get_active_positions(self):
        if self.use_sandbox:
            return []
        try:
            positions = self.exchange.fetch_positions()
            active = []
            for pos in positions:
                contracts = float(pos.get('contracts', 0) or 0)
                if contracts != 0:
                    active.append({
                        "symbol": pos.get('symbol'),
                        "side": pos.get('side'),
                        "contracts": contracts,
                        "entryPrice": float(pos.get('entryPrice', 0) or 0),
                        "markPrice": float(pos.get('markPrice', 0) or 0)
                    })
            return active
        except Exception as e:
            log_message(f"[ERROR] Failed to fetch active positions: {e}. Raising exception.")
            raise RuntimeError(f"Failed to fetch positions: {e}")

    def open_perp_position(self, symbol, side, qty, leverage=10):
        """Places a market order. Returns fill price and success flag."""
        if self.use_sandbox:
            log_message(f"[SANDBOX] Opened simulated {side} position for {qty} contracts of {symbol}.")
            return True, None, "SimOrder_" + str(int(time.time()))
            
        try:
            log_message(f"Setting leverage to {leverage}x for {symbol}...")
            self.exchange.set_leverage(leverage, symbol)
            
            log_message(f"Placing market order: {side} {qty} contracts of {symbol}...")
            if side.upper() == "BUY":
                order = self.exchange.create_market_buy_order(symbol, qty)
            else:
                order = self.exchange.create_market_sell_order(symbol, qty)
                
            fill_price = order.get('average', order.get('price'))
            order_id = order.get('id')
            log_message(f"[SUCCESS] Order placed. ID: {order_id} @ ${fill_price:,.2f}")
            return True, fill_price, order_id
        except Exception as e:
            log_message(f"[ERROR] Critical: Failed to execute live order: {e}. Raising exception.")
            raise RuntimeError(f"Failed to execute live order: {e}")

    def close_perp_position(self, symbol, side, qty):
        """Closes a perp contract."""
        if self.use_sandbox:
            log_message(f"[SANDBOX] Closed simulated {side} position for {qty} contracts of {symbol}.")
            return True, None, "SimClose_" + str(int(time.time()))
            
        try:
            # Side is the exit side (e.g. if we are long, side is SELL)
            log_message(f"Placing close market order: {side} {qty} contracts of {symbol}...")
            if side.upper() == "BUY":
                order = self.exchange.create_market_buy_order(symbol, qty)
            else:
                order = self.exchange.create_market_sell_order(symbol, qty)
                
            fill_price = order.get('average', order.get('price'))
            order_id = order.get('id')
            log_message(f"[SUCCESS] Closed position. ID: {order_id} @ ${fill_price:,.2f}")
            return True, fill_price, order_id
        except Exception as e:
            log_message(f"[ERROR] Critical: Failed to close live position: {e}. Raising exception.")
            raise RuntimeError(f"Failed to close live position: {e}")

    def open_options_spread(self, long_symbol, short_symbol, contracts):
        """Opens a Bull Call Spread option position by buying the long leg and selling the short leg."""
        if self.use_sandbox:
            log_message(f"[SANDBOX] Opened simulated options spread: Buy {long_symbol}, Sell {short_symbol} for {contracts} contracts.")
            return True, 150.0, 50.0, "SimLong_" + str(int(time.time())), "SimShort_" + str(int(time.time()))
            
        try:
            log_message(f"Placing option spread BUY order: {contracts} contracts of {long_symbol}...")
            long_order = self.exchange.create_market_buy_order(long_symbol, contracts)
            long_fill = long_order.get('average', long_order.get('price'))
            if long_fill is None:
                try:
                    ticker = self.exchange.fetch_ticker(long_symbol)
                    long_fill = ticker.get('last') or ticker.get('ask') or 0.0
                except Exception:
                    long_fill = 0.0
            long_id = long_order.get('id')
            log_message(f"[SUCCESS] Long Call Order placed. ID: {long_id} @ ${long_fill:,.2f}")
        except Exception as e:
            log_message(f"[ERROR] Failed to execute long call buy order: {e}. Raising exception.")
            raise RuntimeError(f"Failed to execute long call buy order: {e}")
            
        try:
            log_message(f"Placing option spread SELL order: {contracts} contracts of {short_symbol}...")
            short_order = self.exchange.create_market_sell_order(short_symbol, contracts)
            short_fill = short_order.get('average', short_order.get('price'))
            if short_fill is None:
                try:
                    ticker = self.exchange.fetch_ticker(short_symbol)
                    short_fill = ticker.get('last') or ticker.get('bid') or 0.0
                except Exception:
                    short_fill = 0.0
            short_id = short_order.get('id')
            log_message(f"[SUCCESS] Short Call Order placed. ID: {short_id} @ ${short_fill:,.2f}")
            return True, long_fill, short_fill, long_id, short_id
        except Exception as e:
            log_message(f"[ERROR] Failed to execute short call sell order: {e}. Triggering rollback to liquidate long call leg...")
            try:
                rollback_order = self.exchange.create_market_sell_order(long_symbol, contracts)
                log_message(f"[ROLLBACK] Successfully liquidated long call leg. Order ID: {rollback_order.get('id')}")
            except Exception as rollback_err:
                log_message(f"[CRITICAL ERR] Rollback failed to liquidate long call leg: {rollback_err}")
            raise RuntimeError(f"Failed to execute live options spread: {e}")

    def close_options_spread(self, long_symbol, short_symbol, contracts):
        """Closes a Bull Call Spread option position by selling the long leg and buying the short leg."""
        if self.use_sandbox:
            log_message(f"[SANDBOX] Closed simulated options spread: Sell {long_symbol}, Buy {short_symbol} for {contracts} contracts.")
            return True, 180.0, 30.0
            
        try:
            log_message(f"Placing option spread close SELL order: {contracts} contracts of {long_symbol}...")
            long_order = self.exchange.create_market_sell_order(long_symbol, contracts)
            long_fill = long_order.get('average', long_order.get('price'))
            if long_fill is None:
                try:
                    ticker = self.exchange.fetch_ticker(long_symbol)
                    long_fill = ticker.get('last') or ticker.get('bid') or 0.0
                except Exception:
                    long_fill = 0.0
            log_message(f"[SUCCESS] Long Call Closed. ID: {long_order.get('id')} @ ${long_fill:,.2f}")
            
            log_message(f"Placing option spread close BUY order: {contracts} contracts of {short_symbol}...")
            short_order = self.exchange.create_market_buy_order(short_symbol, contracts)
            short_fill = short_order.get('average', short_order.get('price'))
            if short_fill is None:
                try:
                    ticker = self.exchange.fetch_ticker(short_symbol)
                    short_fill = ticker.get('last') or ticker.get('ask') or 0.0
                except Exception:
                    short_fill = 0.0
            log_message(f"[SUCCESS] Short Call Closed. ID: {short_order.get('id')} @ ${short_fill:,.2f}")
            
            return True, long_fill, short_fill
        except Exception as e:
            log_message(f"[ERROR] Critical: Failed to close live options spread: {e}. Raising exception.")
            raise RuntimeError(f"Failed to close live options spread: {e}")



if __name__ == "__main__":
    desk = TradingDesk()
    log_message("Testing connection...")
    desk.check_connection()

