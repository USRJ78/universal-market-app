# market_sensor.py
import os
import time
import requests
import numpy as np
import ccxt
import math

class MarketSensor:
    def __init__(self, endpoint="https://cdn-ind.testnet.deltaex.org"):
        self.endpoint = endpoint
        self.exchange = ccxt.delta({
            'enableRateLimit': True
        })
        self.exchange.urls['api'] = {
            'public': endpoint,
            'private': endpoint
        }

    def fetch_live_indicators(self):
        """Fetches live prices, funding rates, spreads and calculates realized volatility."""
        indicators = {
            "btc_spot_price": None,
            "btc_perp_price": None,
            "btc_basis_spread_pct": 0.0,
            "btc_funding_apr": 0.0,
            "btc_volatility_annual": 0.45,
            "btc_close_history_100": [],
            "eth_spot_price": None,
            "eth_perp_price": None,
            "eth_basis_spread_pct": 0.0,
            "eth_funding_apr": 0.0,
            "eth_volatility_annual": 0.50,
            "eth_close_history_100": [],
            "india_inflation_yoy": 5.4, # FRED macro default
            "timestamp": time.time()
        }
        
        # 1. Fetch Tickers from Delta Exchange Testnet
        try:
            self.exchange.load_markets()
            tickers = self.exchange.fetch_tickers(['BTC/USDT', 'BTC/USD:USD', 'ETH/USDT', 'ETH/USD:USD'])
            
            # BTC
            t_btc_spot = tickers.get('BTC/USDT')
            t_btc_perp = tickers.get('BTC/USD:USD')
            if t_btc_perp:
                indicators["btc_perp_price"] = t_btc_perp.get('last')
                # Funding Rate APR (continuous estimation)
                info = t_btc_perp.get('info', {})
                if 'funding_rate' in info:
                    indicators["btc_funding_apr"] = float(info['funding_rate']) * 3 * 365 * 100.0
                else:
                    # fetch via fetch_funding_rate
                    try:
                        fr = self.exchange.fetch_funding_rate('BTC/USD:USD')
                        indicators["btc_funding_apr"] = float(fr.get('fundingRate', 0.0)) * 3 * 365 * 100.0
                    except Exception:
                        pass
            
            # Fetch spot from fallback if not on testnet
            if t_btc_spot and t_btc_spot.get('last'):
                indicators["btc_spot_price"] = t_btc_spot.get('last')
            else:
                try:
                    binance = ccxt.binance()
                    bi_t = binance.fetch_ticker('BTC/USDT')
                    indicators["btc_spot_price"] = bi_t.get('last')
                except Exception:
                    pass
                    
            if indicators["btc_spot_price"] and indicators["btc_perp_price"]:
                indicators["btc_basis_spread_pct"] = ((indicators["btc_perp_price"] - indicators["btc_spot_price"]) / indicators["btc_spot_price"]) * 100.0
                
            # ETH
            t_eth_spot = tickers.get('ETH/USDT')
            t_eth_perp = tickers.get('ETH/USD:USD')
            if t_eth_perp:
                indicators["eth_perp_price"] = t_eth_perp.get('last')
                info = t_eth_perp.get('info', {})
                if 'funding_rate' in info:
                    indicators["eth_funding_apr"] = float(info['funding_rate']) * 3 * 365 * 100.0
            if t_eth_spot and t_eth_spot.get('last'):
                indicators["eth_spot_price"] = t_eth_spot.get('last')
            else:
                try:
                    binance = ccxt.binance()
                    bi_t = binance.fetch_ticker('ETH/USDT')
                    indicators["eth_spot_price"] = bi_t.get('last')
                except Exception:
                    pass
                    
            if indicators["eth_spot_price"] and indicators["eth_perp_price"]:
                indicators["eth_basis_spread_pct"] = ((indicators["eth_perp_price"] - indicators["eth_spot_price"]) / indicators["eth_spot_price"]) * 100.0

        except Exception as e:
            print(f"[Sensor] Error fetching Delta indicators: {e}")
            
        # 2. Fetch Volatility & Historical Close Sequences (limit 100)
        # BTC
        try:
            candles = self.exchange.fetch_ohlcv('BTC/USD:USD', timeframe='1h', limit=100)
            closes = [c[4] for c in candles]
            indicators["btc_close_history_100"] = closes
            log_returns = np.diff(np.log(closes))
            vol = np.std(log_returns) * np.sqrt(365 * 24)
            indicators["btc_volatility_annual"] = float(np.clip(vol, 0.15, 1.20))
        except Exception:
            # Fallback history if network fails
            base_p = indicators["btc_spot_price"] or indicators["btc_perp_price"] or 60000.0
            indicators["btc_close_history_100"] = [base_p * (1.0 + 0.0005 * math.sin(i / 5.0)) for i in range(100)]
            
        # ETH
        try:
            candles = self.exchange.fetch_ohlcv('ETH/USD:USD', timeframe='1h', limit=100)
            closes = [c[4] for c in candles]
            indicators["eth_close_history_100"] = closes
            log_returns = np.diff(np.log(closes))
            vol = np.std(log_returns) * np.sqrt(365 * 24)
            indicators["eth_volatility_annual"] = float(np.clip(vol, 0.15, 1.20))
        except Exception:
            base_p = indicators["eth_spot_price"] or indicators["eth_perp_price"] or 1600.0
            indicators["eth_close_history_100"] = [base_p * (1.0 + 0.0008 * math.sin(i / 4.0)) for i in range(100)]

        # 3. Fetch India CPI Macro Indicators from FRED
        try:
            cpi_url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=INDCPIALLMINMEI"
            r = requests.get(cpi_url, timeout=5)
            if r.status_code == 200:
                lines = r.text.strip().split("\n")
                if len(lines) > 13:
                    # Get recent CPI items
                    val_t0 = float(lines[-1].split(",")[1])
                    val_t12 = float(lines[-13].split(",")[1])
                    inflation = ((val_t0 - val_t12) / val_t12) * 100.0
                    indicators["india_inflation_yoy"] = round(inflation, 2)
        except Exception:
            pass

        return indicators

if __name__ == "__main__":
    sensor = MarketSensor()
    print("Testing MarketSensor...")
    data = sensor.fetch_live_indicators()
    import json
    print(json.dumps(data, indent=2))
