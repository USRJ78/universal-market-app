# intelligence_core.py
import os
import requests
import json
import numpy as np
from datetime import datetime
from math_corpus import MathCorpus

def get_julian_date(dt):
    year = dt.year
    month = dt.month
    day = dt.day + dt.hour/24.0 + dt.minute/1440.0
    
    if month <= 2:
        year -= 1
        month += 12
        
    A = int(year / 100)
    B = 2 - A + int(A / 4)
    
    jd = int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + day + B - 1524.5
    return jd

def get_moon_sidereal_longitude(dt):
    JD = get_julian_date(dt)
    T = (JD - 2451545.0) / 36525.0
    
    L_prime = 218.3164477 + 481267.88123421 * T
    D = 297.8501921 + 445267.1114034 * T
    M = 357.5291092 + 35999.0502909 * T
    M_prime = 134.9633964 + 477198.8675055 * T
    F = 93.2720950 + 483202.0175233 * T
    
    L_prime_rad = np.radians(L_prime % 360)
    D_rad = np.radians(D % 360)
    M_rad = np.radians(M % 360)
    M_prime_rad = np.radians(M_prime % 360)
    F_rad = np.radians(F % 360)
    
    d_lam = (
        6.289 * np.sin(M_prime_rad) +
        1.274 * np.sin(2*D_rad - M_prime_rad) +
        0.658 * np.sin(2*D_rad) +
        0.214 * np.sin(2*M_prime_rad) -
        0.186 * np.sin(M_rad) -
        0.114 * np.sin(2*F_rad) +
        0.151 * np.sin(2*D_rad + M_prime_rad) +
        0.143 * np.sin(2*D_rad - M_rad) +
        0.057 * np.sin(2*D_rad - M_prime_rad - M_rad)
    )
    
    tropical_lon = (L_prime + d_lam) % 360
    ayanamsa = 23.85 + 0.01396 * (dt.year - 2000)
    sidereal_lon = (tropical_lon - ayanamsa) % 360
    return sidereal_lon

def get_nakshatra(lon):
    nakshatras = [
        "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra", 
        "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni", 
        "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha", 
        "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", 
        "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"
    ]
    idx = int(lon / (360.0 / 27.0))
    if idx >= 27:
        idx = 26
    return nakshatras[idx]

class IntelligenceCore:
    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self.model = "gemini-1.5-flash"
        self.endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"

    def analyze_and_decide(self, market_state, historical_learnings, active_position=None):
        """Queries Gemini LLM or falls back to local expert heuristics if key is missing."""
        system_prompt = (
            "You are the central intelligence core of the Antigravity AI Brain, a senior quantitative portfolio manager.\n"
            "Your task is to analyze real-time market sensor inputs, consult our historical 10-year backtest knowledge base,\n"
            "and utilize formal mathematical and geometric models (Hurst Exponent, Kelly Criterion, Golden Ratio support levels)\n"
            "to justify strategy selection, optimal leverage, sizing, and entry/exit actions.\n"
            "Note: You MUST respect the 'optimized_parameters' in the market state for each strategy. Use these optimized parameters if they exist.\n"
            "You MUST perform step-by-step Chain of Thought (CoT) logical reasoning and return ONLY a valid JSON object.\n"
            "Note: You MUST size trade_size_usd to use everything in the wallet (wallet_balance, leaving a 2.5% fee buffer) as margin collateral.\n"
            "Do not output markdown code blocks or text outside the JSON. Use this structure:\n"
            "{\n"
            "  \"reasoning\": \"Detailed step-by-step macro, technical, and mathematical rationale...\",\n"
            "  \"regime_classification\": \"e.g. Trend Bullish / Hurst=0.62 (Persistent) / Golden Ratio Reversal / High Volatility\",\n"
            "  \"recommended_strategy\": \"luni_solar_nakshatra | bull_call_spread | options_arb | triangular_arb | stockfish_basis | market_geometry | cash\",\n"
            "  \"action\": \"BUY | SELL | HOLD | CLOSE\",\n"
            "  \"leverage\": 10,\n"
            "  \"trade_size_usd\": 100.0,\n"
            "  \"parameters_override\": {\n"
            "    \"min_profit_pct\": 0.15,\n"
            "    \"timeframe\": \"15m\"\n"
            "  }\n"
            "}"
        )
        
        user_content = f"""
        --- CURRENT MARKET STATE ---
        {json.dumps(market_state, indent=2)}
        
        --- HISTORICAL LEARNINGS CORPUS ---
        {json.dumps(historical_learnings, indent=2)}
        
        --- ACTIVE POSITION STATE ---
        {json.dumps(active_position, indent=2)}
        """

        if self.api_key:
            try:
                headers = {
                    "Content-Type": "application/json"
                }
                payload = {
                    "contents": [
                        {
                            "parts": [
                                {"text": system_prompt},
                                {"text": user_content}
                            ]
                        }
                    ],
                    "generationConfig": {
                        "responseMimeType": "application/json"
                    }
                }
                
                url_with_key = f"{self.endpoint}?key={self.api_key}"
                r = requests.post(url_with_key, json=payload, headers=headers, timeout=15)
                
                if r.status_code == 200:
                    res = r.json()
                    text_content = res['candidates'][0]['content']['parts'][0]['text']
                    return json.loads(text_content.strip())
                else:
                    print(f"[Intelligence] API returned error: Code {r.status_code} - {r.text}")
            except Exception as e:
                print(f"[Intelligence] Failed to query Gemini API: {e}. Falling back to Heuristics.")
                
        return self._run_heuristic_inference(market_state, historical_learnings, active_position)

    def _run_heuristic_inference(self, state, kb, active_pos):
        """Failsafe local reasoning engine based on quantitative expert rules and Luni-Solar astronomy."""
        reasoning_steps = []
        
        # A. Calculate Trend & Hurst Exponent on price history
        btc_closes = state.get("btc_close_history_100", [])
        current_price = state.get("btc_perp_price") or state.get("btc_spot_price") or 60000.0
        
        hurst_btc = MathCorpus.calculate_hurst_exponent(btc_closes)
        
        # Simple trend filter: EMA-like average of closes
        avg_close = np.mean(btc_closes) if btc_closes else current_price
        is_bullish_trend = current_price > avg_close
        
        regime_math = f"Hurst={hurst_btc:.2f} ({'Trending' if hurst_btc > 0.5 else 'Mean-Reverting'})"
        trend_status = "BULLISH" if is_bullish_trend else "BEARISH"
        reasoning_steps.append(f"Trend classification is {trend_status} relative to history mean. {regime_math}.")
        
        # B. Astrological Moon Transit Calculation
        now_dt = datetime.utcnow()
        lon = get_moon_sidereal_longitude(now_dt)
        curr_nak = get_nakshatra(lon)
        
        # Best Nakshatras identified in 10-year backtests
        long_naks = {"Ashwini", "Bharani", "Rohini", "Pushya", "Hasta", "Uttara Phalguni", "Anuradha", "Shravana", "Uttara Bhadrapada", "Revati"}
        short_naks = {"Krittika", "Ardra", "Ashlesha", "Purva Phalguni", "Chitra", "Vishakha", "Jyeshtha", "Mula", "Shatabhisha", "Purva Bhadrapada"}
        
        reasoning_steps.append(f"Sidereal moon longitude: {lon:.2f}° | Nakshatra: {curr_nak}")
        
        # C. Decide Action & Strategy
        # Best Nakshatras identified in 10-year backtests
        long_naks = {"Ashwini", "Bharani", "Rohini", "Pushya", "Hasta", "Uttara Phalguni", "Anuradha", "Shravana", "Uttara Bhadrapada", "Revati"}
        short_naks = {"Krittika", "Ardra", "Ashlesha", "Purva Phalguni", "Chitra", "Vishakha", "Jyeshtha", "Mula", "Shatabhisha", "Purva Bhadrapada"}

        # Determine Nakshatra signal
        nak_action = "HOLD"
        if curr_nak in long_naks:
            if is_bullish_trend:
                nak_action = "BUY"
                reasoning_steps.append(f"Luni-Solar Signal: Moon is in bullish Nakshatra '{curr_nak}' and trend is BULLISH. Recommended action: BUY.")
            else:
                reasoning_steps.append(f"Luni-Solar Signal: Moon is in bullish Nakshatra '{curr_nak}' but trend is BEARISH. Recommended action: HOLD (cash).")
        elif curr_nak in short_naks:
            if not is_bullish_trend:
                nak_action = "SELL"
                reasoning_steps.append(f"Luni-Solar Signal: Moon is in bearish Nakshatra '{curr_nak}' and trend is BEARISH. Recommended action: SELL.")
            else:
                reasoning_steps.append(f"Luni-Solar Signal: Moon is in bearish Nakshatra '{curr_nak}' but trend is BULLISH. Recommended action: HOLD (cash).")
        else:
            reasoning_steps.append(f"Luni-Solar Signal: Moon is in neutral Nakshatra '{curr_nak}'. Recommended action: HOLD (cash).")

        # Portfolio sizing parameter setup
        wallet_balance = state.get("wallet_balance", 1000.0)
        usable_wallet_balance = wallet_balance * 0.975

        if nak_action in ["BUY", "SELL"]:
            rec_strat = "luni_solar_nakshatra"
            leverage = 1.5
            trade_size = round(usable_wallet_balance * leverage * 0.5, 2) # deploy 50% margin
            action = nak_action
            
            if active_pos:
                strat_name = active_pos.get("strategy")
                active_direction = active_pos.get("direction", "BUY").upper()
                if strat_name != rec_strat:
                    action = "CLOSE"
                    reasoning_steps.append(f"Rebalancing portfolio: shifting from active strategy '{strat_name}' to '{rec_strat}'. Recommended action: CLOSE.")
                elif nak_action != active_direction:
                    action = "CLOSE"
                    reasoning_steps.append(f"Signal reversed from {active_direction} to {nak_action}. Closing active position.")
                else:
                    action = "HOLD"
                    reasoning_steps.append(f"Active Nakshatra position matches current signal ({nak_action}). Recommended action: HOLD.")
        else:
            # No Nakshatra trigger: continuous repeating Bull Call Spread options strategy using wallet funds
            rec_strat = "bull_call_spread"
            leverage = 10
            # Sizing optimized to utilize everything in the wallet (leaving 2.5% fee buffer) as margin collateral
            trade_size = round(usable_wallet_balance * leverage * 0.5, 2)
            
            if active_pos:
                strat_name = active_pos.get("strategy")
                if strat_name != rec_strat:
                    action = "CLOSE"
                    reasoning_steps.append(f"Rebalancing portfolio: shifting from active strategy '{strat_name}' to '{rec_strat}'. Recommended action: CLOSE.")
                else:
                    # Monitor the active option spread
                    unrealized_pnl = active_pos.get("unrealized_pnl", 0.0)
                    tp_target = active_pos.get("tp_target", 0.0)
                    sl_target = active_pos.get("sl_target", 0.0)
                    
                    if tp_target > 0 and unrealized_pnl >= tp_target:
                        action = "CLOSE"
                        reasoning_steps.append(f"Option Spread Profit Target Hit: Unrealized PnL ${unrealized_pnl:.4f} USD >= TP Target ${tp_target:.4f} USD. Closing position.")
                    elif sl_target > 0 and unrealized_pnl <= -sl_target:
                        action = "CLOSE"
                        reasoning_steps.append(f"Option Spread Stop Loss Hit: Unrealized PnL ${unrealized_pnl:.4f} USD <= SL Target -${sl_target:.4f} USD. Closing position.")
                    else:
                        action = "HOLD"
                        reasoning_steps.append(f"Active Option Spread PnL: {unrealized_pnl:+.4f} USD (TP: {tp_target:.4f}, SL: -{sl_target:.4f}). Below triggers. Recommended action: HOLD.")
            else:
                action = "BUY"
                reasoning_steps.append(f"No Nakshatra trigger. Engaging fallback Bull Call Spread options strategy. Recommended action: BUY.")

        # Respect optimized_parameters from state if any
        opt_params = state.get("optimized_parameters", {}).get(rec_strat, {})
        leverage = opt_params.get("leverage", leverage)
        timeframe = opt_params.get("timeframe", "1d" if rec_strat == "luni_solar_nakshatra" else "15m")
        
        decision = {
            "reasoning": " | ".join(reasoning_steps),
            "regime_classification": f"Nakshatra {curr_nak} / Trend {trend_status} / {regime_math}",
            "recommended_strategy": rec_strat,
            "action": action,
            "leverage": leverage,
            "trade_size_usd": trade_size,
            "parameters_override": {
                "min_profit_pct": 0.15,
                "timeframe": timeframe
            }
        }
        
        return decision

if __name__ == "__main__":
    core = IntelligenceCore()
    print("Testing Heuristic Inference Engine (Luni-Solar Nakshatra default)...")
    from market_sensor import MarketSensor
    from knowledge_base import KnowledgeBase
    
    state = MarketSensor().fetch_live_indicators()
    kb = KnowledgeBase().load_historical_learnings()
    
    res = core.analyze_and_decide(state, kb)
    print(json.dumps(res, indent=2))
