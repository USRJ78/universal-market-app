# self_optimizer.py
import json
import os
import numpy as np

class SelfOptimizer:
    @staticmethod
    def analyze_performance(trades):
        """
        Parses completed trades from the state file ledger and calculates
        real-time realized performance metrics, win rates, and reflections.
        """
        if not trades:
            # Baseline backtest fallback if no live trades completed yet
            return {
                "portfolio_metrics": {
                    "total_trades": 0,
                    "win_rate": 0.474, # Backtest baseline Nifty/BTC
                    "payout_ratio": 1.5,
                    "net_profit_usd": 0.0,
                    "total_fees_usd": 0.0,
                    "sharpe_ratio": 0.0
                },
                "strategy_metrics": {},
                "self_reflections": [
                    "No live trades executed yet. Relying on historical 10-year backtest priors for strategy selection and Kelly sizing."
                ]
            }

        total_trades = len(trades)
        profits = [t.get("net_profit_usd", 0.0) for t in trades]
        fees = [t.get("fees_usd", 0.0) for t in trades]
        
        wins = [p for p in profits if p > 0]
        losses = [abs(p) for p in profits if p <= 0]
        
        winning_count = len(wins)
        losing_count = len(losses)
        
        win_rate = winning_count / total_trades if total_trades > 0 else 0.474
        
        avg_win = np.mean(wins) if len(wins) > 0 else 0.0
        avg_loss = np.mean(losses) if len(losses) > 0 else 0.0
        
        if avg_loss > 0:
            payout_ratio = avg_win / avg_loss
        else:
            payout_ratio = float('inf') if avg_win > 0 else 1.5

        total_std = np.std(profits) if len(profits) > 1 else 0.0
        total_mean = np.mean(profits) if len(profits) > 0 else 0.0
        sharpe_ratio = total_mean / total_std if total_std > 0 else 0.0

        # Group by strategy
        strategies = {}
        for t in trades:
            strat = t.get("strategy", "unknown")
            if strat not in strategies:
                strategies[strat] = []
            strategies[strat].append(t)
            
        strategy_metrics = {}
        self_reflections = []
        
        for strat, strat_trades in strategies.items():
            s_total = len(strat_trades)
            s_profits = [st.get("net_profit_usd", 0.0) for st in strat_trades]
            s_wins = [sp for sp in s_profits if sp > 0]
            s_losses = [abs(sp) for sp in s_profits if sp <= 0]
            
            s_win_rate = len(s_wins) / s_total if s_total > 0 else 0.0
            s_avg_win = np.mean(s_wins) if len(s_wins) > 0 else 0.0
            s_avg_loss = np.mean(s_losses) if len(s_losses) > 0 else 0.0
            
            s_payout = s_avg_win / s_avg_loss if s_avg_loss > 0 else float('inf') if s_avg_win > 0 else 1.0
            s_net_profit = sum(s_profits)
            
            s_std = np.std(s_profits) if len(s_profits) > 1 else 0.0
            s_mean = np.mean(s_profits) if len(s_profits) > 0 else 0.0
            s_sharpe = s_mean / s_std if s_std > 0 else 0.0
            
            strategy_metrics[strat] = {
                "total_trades": s_total,
                "win_rate": float(s_win_rate),
                "payout_ratio": float(s_payout) if not np.isinf(s_payout) else "inf",
                "net_profit_usd": float(s_net_profit),
                "sharpe_ratio": float(s_sharpe)
            }
            
            # Formulation of self-reflections
            if s_total >= 3:
                # Review recent performance
                recent_trades = strat_trades[-3:]
                recent_profits = [rt.get("net_profit_usd", 0.0) for rt in recent_trades]
                recent_wins = len([rp for rp in recent_profits if rp > 0])
                recent_win_rate = recent_wins / 3.0
                
                if recent_win_rate < 0.35:
                    self_reflections.append(
                        f"🚨 Strategy '{strat}' exhibits recent underperformance (win rate {recent_win_rate:.1%}). "
                        "Recommending dynamic Kelly size downscaling to prevent capital erosion."
                    )
                elif recent_win_rate > 0.65:
                    self_reflections.append(
                        f"📈 Strategy '{strat}' exhibits strong recent performance (win rate {recent_win_rate:.1%}). "
                        "Highly aligned with the current market regime. Sizing up weights."
                    )

        if not self_reflections:
            self_reflections.append(
                f"Overall portfolio tracking: {total_trades} trades. Realized win rate {win_rate:.1%}, payout ratio {payout_ratio:.2f}. "
                "Calculations remain stable. Continuing standard execution."
            )
            
        return {
            "portfolio_metrics": {
                "total_trades": int(total_trades),
                "win_rate": float(win_rate),
                "payout_ratio": float(payout_ratio) if not np.isinf(payout_ratio) else "inf",
                "net_profit_usd": float(sum(profits)),
                "total_fees_usd": float(sum(fees)),
                "sharpe_ratio": float(sharpe_ratio)
            },
            "strategy_metrics": strategy_metrics,
            "self_reflections": self_reflections
        }

    @staticmethod
    def generate_shutdown_summary_report(trades):
        """
        Generates a clean, human-readable terminal/log shutdown report summarizing
        metrics (win rate, Sharpe ratio, profit/loss) for all strategies.
        """
        if not trades:
            return (
                "\n==================================================\n"
                "🧠 ANTIGRAVITY AI BRAIN SHUTDOWN SUMMARY REPORT\n"
                "==================================================\n"
                "No live trades were executed during this session.\n"
                "=================================================="
            )
            
        analysis = SelfOptimizer.analyze_performance(trades)
        p_metrics = analysis["portfolio_metrics"]
        s_metrics = analysis["strategy_metrics"]
        
        lines = []
        lines.append("")
        lines.append("==================================================")
        lines.append("🧠 ANTIGRAVITY AI BRAIN SHUTDOWN SUMMARY REPORT")
        lines.append("==================================================")
        lines.append("PORTFOLIO PERFORMANCE REVIEW:")
        lines.append(f"  - Total Trades: {p_metrics['total_trades']}")
        lines.append(f"  - Realized Win Rate: {p_metrics['win_rate']:.1%}")
        lines.append(f"  - Net Profit/Loss: ${p_metrics['net_profit_usd']:+.4f} USD")
        lines.append(f"  - Portfolio Sharpe Ratio (Trade-based): {p_metrics['sharpe_ratio']:.4f}")
        lines.append(f"  - Total Fees Paid: ${p_metrics['total_fees_usd']:.4f} USD")
        lines.append("--------------------------------------------------")
        lines.append("STRATEGY PERFORMANCE BREAKDOWN:")
        
        highest_profit = -float('inf')
        highest_strat = "None"
        
        for strat, s_data in s_metrics.items():
            lines.append(f"Strategy: '{strat}'")
            lines.append(f"  - Total Trades: {s_data['total_trades']}")
            lines.append(f"  - Win Rate: {s_data['win_rate']:.1%}")
            lines.append(f"  - Net Profit/Loss: ${s_data['net_profit_usd']:+.4f} USD")
            lines.append(f"  - Sharpe Ratio (Trade-based): {s_data['sharpe_ratio']:.4f}")
            lines.append(f"  - Payout Ratio: {s_data['payout_ratio']}")
            lines.append("")
            
            if s_data['net_profit_usd'] > highest_profit:
                highest_profit = s_data['net_profit_usd']
                highest_strat = strat
            
        lines.append("--------------------------------------------------")
        if highest_strat != "None":
            lines.append(f"🏆 HIGHEST PERFORMING STRATEGY: '{highest_strat}' (Net Profit: ${highest_profit:+.4f} USD)")
        else:
            lines.append("🏆 HIGHEST PERFORMING STRATEGY: None")
        lines.append("==================================================")
        
        return "\n".join(lines)

if __name__ == "__main__":
    print("Testing SelfOptimizer...")
    mock_trades = [
        {"strategy": "market_geometry", "net_profit_usd": 15.0, "fees_usd": 1.2},
        {"strategy": "market_geometry", "net_profit_usd": -5.0, "fees_usd": 1.2},
        {"strategy": "triangular_arb", "net_profit_usd": 2.0, "fees_usd": 0.5},
        {"strategy": "market_geometry", "net_profit_usd": -8.0, "fees_usd": 1.2},
        {"strategy": "market_geometry", "net_profit_usd": -12.0, "fees_usd": 1.2},
    ]
    res = SelfOptimizer.analyze_performance(mock_trades)
    print(json.dumps(res, indent=4))
