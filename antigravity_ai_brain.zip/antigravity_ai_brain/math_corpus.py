# math_corpus.py
import math
import numpy as np

# Ensure standard mathematical constants
GOLDEN_RATIO = (1.0 + math.sqrt(5.0)) / 2.0  # Approx 1.6180339887

def normal_cdf(x):
    """Calculates the standard normal cumulative distribution function using math.erf."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

def normal_pdf(x):
    """Calculates the standard normal probability density function."""
    return (1.0 / math.sqrt(2.0 * math.pi)) * math.exp(-0.5 * x**2)

class MathCorpus:
    @staticmethod
    def calculate_hurst_exponent(prices):
        """
        Calculates the Hurst Exponent (H) of a price series using rescaled range (R/S) analysis.
        H < 0.5: Mean-reverting series.
        H = 0.5: Random walk (Brownian motion).
        H > 0.5: Trending series.
        """
        prices = np.array(prices, dtype=float)
        if len(prices) < 10:
            return 0.5 # Neutral fallback
            
        try:
            # 1. Compute log returns
            log_returns = np.diff(np.log(prices))
            n = len(log_returns)
            
            # 2. Calculate mean-adjusted returns
            mean_ret = np.mean(log_returns)
            mean_adj = log_returns - mean_ret
            
            # 3. Cumulative deviation
            cum_dev = np.cumsum(mean_adj)
            
            # 4. Calculate Range (R) and Standard Deviation (S)
            r = np.max(cum_dev) - np.min(cum_dev)
            s = np.std(log_returns)
            
            if s == 0:
                return 0.5
                
            rs = r / s
            if rs <= 0:
                return 0.5
                
            # 5. Approximate Hurst exponent H = ln(R/S) / ln(N)
            h = math.log(rs) / math.log(n)
            
            # Bound the Hurst Exponent between 0.05 and 0.95 to avoid extreme estimation artifacts
            return float(np.clip(h, 0.05, 0.95))
        except Exception:
            return 0.5

    @staticmethod
    def calculate_kelly_fraction(win_probability, win_loss_ratio, fraction_multiplier=0.5):
        """
        Calculates the optimal trade sizing fraction using the Kelly Criterion.
        f* = (p * b - q) / b = p - (1 - p) / b
        p = probability of winning
        b = payout ratio (average win size / average loss size)
        fraction_multiplier: fraction of Kelly to allocate (e.g. 0.5 for Half-Kelly to manage risk)
        """
        p = float(win_probability)
        b = float(win_loss_ratio)
        
        # Safety bounds
        if p <= 0.0:
            return 0.0
        if p >= 1.0:
            p = 0.99  # Cap win probability below 1.0
            
        if b <= 0.0:
            b = 1.0  # Default payout ratio fallback
            
        q = 1.0 - p
        
        # As payout ratio b approaches infinity (e.g. no losses yet), kelly fraction approaches p
        if math.isinf(b) or b > 1000.0:
            kelly = p
        else:
            kelly = (p * b - q) / b
            
        # Risk management: clip to positive Kelly and apply fractional multiplier
        allocated = max(0.0, kelly) * fraction_multiplier
        # Bound maximum allocation to 20% of capital to prevent leverage blowups
        return float(min(allocated, 0.20))

    @staticmethod
    def calculate_fibonacci_levels(high, low):
        """
        Calculates standard geometric Fibonacci retracement levels between a given High and Low.
        Levels: 0.0% (High), 23.6%, 38.2%, 50.0%, 61.8%, 78.6%, 100.0% (Low).
        """
        high = float(high)
        low = float(low)
        diff = high - low
        
        return {
            "fib_0": high,                   # 0.0%
            "fib_236": high - 0.236 * diff,  # 23.6%
            "fib_382": high - 0.382 * diff,  # 38.2%
            "fib_500": high - 0.500 * diff,  # 50.0%
            "fib_618": high - 0.618 * diff,  # 61.8%
            "fib_786": high - 0.786 * diff,  # 78.6%
            "fib_100": low,                  # 100.0%
            "golden_ratio_expansion": high + (GOLDEN_RATIO - 1.0) * diff # 1.618 extension
        }

    @staticmethod
    def euclidean_distance(x1, y1, x2, y2):
        """Calculates the standard Euclidean geometry distance between two coordinate points."""
        return float(math.sqrt((x2 - x1)**2 + (y2 - y1)**2))

    @staticmethod
    def black_scholes_greeks(s, k, t, r, sigma):
        """
        Calculates Black-Scholes-Merton option price and risk Greeks (Delta, Gamma, Vega, Theta).
        s: Spot underlying price
        k: Strike price
        t: Time to maturity (in years)
        r: Risk-free interest rate (e.g. 0.07 for 7%)
        sigma: Volatility (annualized, e.g. 0.40 for 40%)
        """
        s = float(s)
        k = float(k)
        t = float(t)
        r = float(r)
        sigma = float(sigma)
        
        if t <= 0.001 or sigma <= 0.001:
            # Under expiry limits
            return {
                "call_price": max(0.0, s - k),
                "put_price": max(0.0, k - s),
                "call_delta": 1.0 if s > k else 0.0,
                "put_delta": -1.0 if s < k else 0.0,
                "gamma": 0.0,
                "vega": 0.0,
                "theta_call": 0.0
            }
            
        try:
            d1 = (math.log(s / k) + (r + 0.5 * sigma**2) * t) / (sigma * math.sqrt(t))
            d2 = d1 - sigma * math.sqrt(t)
            
            # Price
            call_price = s * normal_cdf(d1) - k * math.exp(-r * t) * normal_cdf(d2)
            put_price = k * math.exp(-r * t) * normal_cdf(-d2) - s * normal_cdf(-d1)
            
            # Greeks
            call_delta = normal_cdf(d1)
            put_delta = call_delta - 1.0
            
            gamma = normal_pdf(d1) / (s * sigma * math.sqrt(t))
            vega = s * math.sqrt(t) * normal_pdf(d1)
            
            # Theta
            term1 = -(s * normal_pdf(d1) * sigma) / (2.0 * math.sqrt(t))
            term2 = r * k * math.exp(-r * t)
            
            theta_call = term1 - term2 * normal_cdf(d2)
            theta_put = term1 + term2 * normal_cdf(-d2)
            
            return {
                "call_price": float(call_price),
                "put_price": float(put_price),
                "call_delta": float(call_delta),
                "put_delta": float(put_delta),
                "gamma": float(gamma),
                "vega": float(vega),
                "theta_call": float(theta_call),
                "theta_put": float(theta_put)
            }
        except Exception:
            return {
                "call_price": max(0.0, s - k),
                "put_price": max(0.0, k - s),
                "call_delta": 0.5,
                "put_delta": -0.5,
                "gamma": 0.0,
                "vega": 0.0,
                "theta_call": 0.0
            }

    @staticmethod
    def simulate_gbm_paths(s0, mu, sigma, t_years, steps, num_paths=1000):
        """
        Simulates price paths using Geometric Brownian Motion (GBM):
        dS_t = mu * S_t * dt + sigma * S_t * dW_t
        """
        dt = t_years / steps
        # Matrix of random standard normal variables
        z = np.random.normal(0.0, 1.0, (num_paths, steps))
        
        # Compute price changes using Vectorized Numpy math
        paths = np.zeros((num_paths, steps + 1))
        paths[:, 0] = s0
        
        drift = (mu - 0.5 * sigma**2) * dt
        diffusion = sigma * math.sqrt(dt)
        
        for t in range(steps):
            paths[:, t + 1] = paths[:, t] * np.exp(drift + diffusion * z[:, t])
            
        return paths

if __name__ == "__main__":
    print("Testing MathCorpus calculations...")
    test_prices = [100 + math.sin(i/5.0)*5 + i*0.2 for i in range(100)]
    h = MathCorpus.calculate_hurst_exponent(test_prices)
    print(f"Hurst Exponent (Trending): {h:.4f}")
    
    k = MathCorpus.calculate_kelly_fraction(0.55, 1.5)
    print(f"Kelly Fraction (Win 55%, 1.5 ratio): {k:.4f}")
    
    fibs = MathCorpus.calculate_fibonacci_levels(100, 80)
    print(f"Fibonacci levels (100 to 80): {fibs['fib_618']:.2f}")
    
    greeks = MathCorpus.black_scholes_greeks(60000, 62000, 30/365, 0.07, 0.50)
    print(f"Call option price: ${greeks['call_price']:.2f} | Call Delta: {greeks['call_delta']:.4f}")
