# verify_ai_brain.py
import os
import sys
import json
import numpy as np
import math

# Ensure UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

from market_sensor import MarketSensor
from knowledge_base import KnowledgeBase
from intelligence_core import IntelligenceCore
from trading_desk import TradingDesk
from math_corpus import MathCorpus
from self_optimizer import SelfOptimizer

def test_math_corpus():
    print("[TEST] Testing MathCorpus calculations...")
    
    # 1. Hurst Exponent
    trending_series = [100.0 + i * 1.5 + np.random.normal(0, 0.2) for i in range(100)]
    h_trend = MathCorpus.calculate_hurst_exponent(trending_series)
    print(f"  - Hurst (Trending Series): {h_trend:.4f}")
    assert 0.5 <= h_trend <= 0.95, f"Expected persistent Hurst index for trending series, got {h_trend}"
    
    reverting_series = [100.0 + math.sin(i * 2.0) * 2.0 for i in range(100)]
    h_rev = MathCorpus.calculate_hurst_exponent(reverting_series)
    print(f"  - Hurst (Reverting Series): {h_rev:.4f}")
    assert 0.05 <= h_rev <= 0.55, f"Expected anti-persistent Hurst index for mean-reverting series, got {h_rev}"
    
    # 2. Kelly Criterion
    k_fraction = MathCorpus.calculate_kelly_fraction(win_probability=0.55, win_loss_ratio=1.5, fraction_multiplier=0.5)
    print(f"  - Kelly Sizing Fraction (win=55%, payout=1.5, half-Kelly): {k_fraction:.4%}")
    assert 0.0 < k_fraction <= 0.20, f"Expected safe bounded Kelly fraction, got {k_fraction}"
    
    # 3. Fibonacci Levels
    fibs = MathCorpus.calculate_fibonacci_levels(high=100.0, low=80.0)
    print(f"  - Fibonacci 61.8% Level: {fibs['fib_618']:.2f}")
    assert math.isclose(fibs["fib_618"], 87.64), f"Expected Fib 61.8% at 87.64, got {fibs['fib_618']}"
    assert fibs["golden_ratio_expansion"] > 100.0
    
    # 4. Black-Scholes Greeks
    greeks = MathCorpus.black_scholes_greeks(s=60000.0, k=62000.0, t=30.0/365.0, r=0.07, sigma=0.50)
    print(f"  - Option Price: Call=${greeks['call_price']:.2f} | Put=${greeks['put_price']:.2f}")
    print(f"  - Greeks: Call Delta={greeks['call_delta']:.4f} | Gamma={greeks['gamma']:.6f} | Vega={greeks['vega']:.2f}")
    assert greeks["call_price"] > 0
    assert 0.0 <= greeks["call_delta"] <= 1.0
    assert greeks["gamma"] > 0
    
    # 5. Geometric Brownian Motion Path Simulation
    paths = MathCorpus.simulate_gbm_paths(s0=100, mu=0.05, sigma=0.2, t_years=1.0, steps=10, num_paths=5)
    print(f"  - GBM Simulation Output shape: {paths.shape}")
    assert paths.shape == (5, 11)
    assert np.all(paths[:, 0] == 100.0)
    
    print("[PASS] MathCorpus verified successfully.\n")

def test_self_optimizer():
    print("[TEST] Testing SelfOptimizer and Kelly self-learning adaptations...")
    
    # 1. Test empty ledger fallback
    metrics_empty = SelfOptimizer.analyze_performance([])
    assert metrics_empty["portfolio_metrics"]["total_trades"] == 0
    assert metrics_empty["portfolio_metrics"]["win_rate"] == 0.474
    assert "No live trades executed" in metrics_empty["self_reflections"][0]
    
    # 2. Test dynamic analysis on losing trades
    mock_losing_trades = [
        {"strategy": "market_geometry", "net_profit_usd": -20.0, "fees_usd": 1.0},
        {"strategy": "market_geometry", "net_profit_usd": -15.0, "fees_usd": 1.0},
        {"strategy": "market_geometry", "net_profit_usd": -10.0, "fees_usd": 1.0}
    ]
    metrics_losing = SelfOptimizer.analyze_performance(mock_losing_trades)
    assert metrics_losing["portfolio_metrics"]["total_trades"] == 3
    assert metrics_losing["portfolio_metrics"]["win_rate"] == 0.0
    assert any("underperformance" in ref for ref in metrics_losing["self_reflections"])
    
    # 3. Test dynamic analysis on winning trades
    mock_winning_trades = [
        {"strategy": "market_geometry", "net_profit_usd": 20.0, "fees_usd": 1.0},
        {"strategy": "market_geometry", "net_profit_usd": 15.0, "fees_usd": 1.0},
        {"strategy": "market_geometry", "net_profit_usd": 10.0, "fees_usd": 1.0}
    ]
    metrics_winning = SelfOptimizer.analyze_performance(mock_winning_trades)
    assert metrics_winning["portfolio_metrics"]["total_trades"] == 3
    assert metrics_winning["portfolio_metrics"]["win_rate"] == 1.0
    assert any("strong recent performance" in ref for ref in metrics_winning["self_reflections"])
    
    # 4. Test report generation and Sharpe calculations
    report_empty = SelfOptimizer.generate_shutdown_summary_report([])
    assert "No live trades were executed" in report_empty
    
    report_losing = SelfOptimizer.generate_shutdown_summary_report(mock_losing_trades)
    assert "🧠 ANTIGRAVITY AI BRAIN SHUTDOWN SUMMARY REPORT" in report_losing
    assert "Portfolio Sharpe Ratio (Trade-based): -3.6742" in report_losing
    assert "HIGHEST PERFORMING STRATEGY: None" in report_losing or "HIGHEST PERFORMING STRATEGY: 'market_geometry'" in report_losing
    
    report_winning = SelfOptimizer.generate_shutdown_summary_report(mock_winning_trades)
    assert "Portfolio Sharpe Ratio (Trade-based): 3.6742" in report_winning
    assert "HIGHEST PERFORMING STRATEGY: 'market_geometry'" in report_winning
    
    print("[PASS] SelfOptimizer verified successfully.\n")
    return metrics_losing, metrics_winning

def test_market_sensor():
    print("[TEST] Testing MarketSensor (with sequence data)...")
    sensor = MarketSensor()
    indicators = sensor.fetch_live_indicators()
    
    assert indicators is not None, "Indicators should not be None"
    required_keys = [
        "btc_spot_price", "btc_perp_price", "btc_basis_spread_pct",
        "btc_funding_apr", "btc_volatility_annual", "india_inflation_yoy",
        "timestamp", "btc_close_history_100", "eth_close_history_100"
    ]
    for key in required_keys:
        assert key in indicators, f"Missing key in indicators: {key}"
        
    btc_closes = indicators["btc_close_history_100"]
    eth_closes = indicators["eth_close_history_100"]
    
    assert len(btc_closes) == 100, f"Expected 100 BTC close prices, got {len(btc_closes)}"
    assert len(eth_closes) == 100, f"Expected 100 ETH close prices, got {len(eth_closes)}"
    assert all(isinstance(x, (int, float)) and x > 0 for x in btc_closes)
    
    print(f"  - Spot Price: {indicators['btc_spot_price']}")
    print(f"  - History Closes (first 3): {btc_closes[:3]}")
    print("[PASS] MarketSensor verified successfully.\n")
    return indicators

def test_knowledge_base():
    print("[TEST] Testing KnowledgeBase...")
    kb = KnowledgeBase()
    learnings = kb.load_historical_learnings()
    
    assert learnings is not None, "Learnings should not be None"
    assert "mathematical_geometry_reference" in learnings, "Missing mathematical_geometry_reference"
    
    ref = learnings["mathematical_geometry_reference"]
    print(f"  - Math Reference Loaded. Hurst Exponent Definition: {ref['hurst_exponent']}")
    
    print("[PASS] KnowledgeBase verified successfully.\n")
    return learnings

def test_intelligence_core(market_state, learnings):
    print("[TEST] Testing IntelligenceCore (with Hurst and Kelly reasoning)...")
    core = IntelligenceCore()
    
    # Test baseline decision output
    decision = core.analyze_and_decide(market_state, learnings, active_position=None)
    assert decision is not None, "Decision should not be None"
    size_base = decision["trade_size_usd"]
    print(f"  - Recommended Strategy: {decision['recommended_strategy']}")
    print(f"  - Baseline Trade Size: ${size_base}")
    print(f"  - Baseline Regime: {decision['regime_classification']}")
    
    # Simulate a learning loop: feed losing reflections to scale down trade sizing
    mock_losing_trades = [
        {"strategy": "bull_call_spread", "net_profit_usd": 25.0, "fees_usd": 1.0}, # Win
        {"strategy": "bull_call_spread", "net_profit_usd": -10.0, "fees_usd": 1.0}, # Loss
        {"strategy": "bull_call_spread", "net_profit_usd": -10.0, "fees_usd": 1.0}  # Loss
    ]
    metrics_losing = SelfOptimizer.analyze_performance(mock_losing_trades)
    
    trending_state = dict(market_state)
    kb_losing = KnowledgeBase().load_historical_learnings(metrics_losing)
    decision_losing = core.analyze_and_decide(trending_state, kb_losing, active_position=None)
    
    size_losing = decision_losing["trade_size_usd"]
    print(f"  - Losing Trend Recommended Strategy: {decision_losing['recommended_strategy']}")
    print(f"  - Losing Trend Size (Scaled Down): ${size_losing}")
    print(f"  - Losing Trend Reason: {decision_losing['reasoning']}")
    
    # Verify dynamic self-learning optimization sized down the trade
    assert "cut Kelly size by 50%" in decision_losing["reasoning"], "Expected Kelly downscale reflection in reasoning logs"
    assert size_losing < size_base, f"Expected scaled-down sizing, got {size_losing}"
    
    print("[PASS] IntelligenceCore verified successfully.\n")

def test_trading_desk():
    print("[TEST] Testing TradingDesk (Sandbox & Failsafe fallback)...")
    
    desk_sandbox = TradingDesk(use_sandbox=True)
    assert desk_sandbox.check_connection() is True
    bal = desk_sandbox.get_wallet_balance()
    assert bal == 1000.0
    
    # Verify environment keys extraction
    os.environ["DELTA_API_KEY"] = "test_env_key"
    os.environ["DELTA_API_SECRET"] = "test_env_secret"
    
    desk_env = TradingDesk(use_sandbox=True)
    assert desk_env.api_key == "test_env_key"
    assert desk_env.api_secret == "test_env_secret"
    
    # Cleanup environment variables
    del os.environ["DELTA_API_KEY"]
    del os.environ["DELTA_API_SECRET"]
    
    print("[PASS] TradingDesk verified successfully.\n")

def test_strategy_rotation_and_optimization():
    print("[TEST] Testing Strategy Rotation and Parameter Optimization Loop...")
    
    market_state = {
        "btc_spot_price": 60000.0,
        "btc_perp_price": 60000.0,
        "btc_basis_spread_pct": 0.0,
        "btc_funding_apr": 0.0,
        "btc_volatility_annual": 0.40,
        "india_inflation_yoy": 3.0,
        "wallet_balance": 1000.0,
        "btc_close_history_100": [60000.0] * 100,
        "eth_close_history_100": [1600.0] * 100,
        "timestamp": 123456789.0,
        "consecutive_failures": {
            "triangular_arb": 3
        },
        "optimized_parameters": {}
    }
    
    kb = KnowledgeBase().load_historical_learnings()
    core = IntelligenceCore()
    
    decision = core.analyze_and_decide(market_state, kb, active_position=None)
    print(f"  - Recommended strategy for failed 'triangular_arb': {decision['recommended_strategy']}")
    
    active_pos = {
        "symbol": "BTC/USD:USD",
        "strategy": "bull_call_spread",
        "direction": "BUY",
        "qty": 10,
        "fill_price": 60000.0,
        "unrealized_pnl": 10.0
    }
    
    state_with_opt = dict(market_state)
    state_with_opt["optimized_parameters"] = {
        "bull_call_spread": {
            "min_profit_pct": 0.25,
            "leverage": 8,
            "timeframe": "1h"
        }
    }
    
    dec_tp = core.analyze_and_decide(state_with_opt, kb, active_position=active_pos)
    print(f"  - Action when PnL ($10) >= TP ($1.50): {dec_tp['action']} | Reasoning: {dec_tp['reasoning']}")
    assert dec_tp["action"] == "CLOSE", "Expected exit trigger for Take Profit"
    
    active_pos["unrealized_pnl"] = -4.0
    dec_sl = core.analyze_and_decide(state_with_opt, kb, active_position=active_pos)
    print(f"  - Action when PnL (-$4.00) <= SL (-$3.00): {dec_sl['action']} | Reasoning: {dec_sl['reasoning']}")
    assert dec_sl["action"] == "CLOSE", "Expected exit trigger for Stop Loss"
    
    active_pos["unrealized_pnl"] = 0.5
    dec_hold = core.analyze_and_decide(state_with_opt, kb, active_position=active_pos)
    print(f"  - Action when PnL ($0.50) is neutral: {dec_hold['action']}")
    assert dec_hold["action"] == "HOLD", "Expected HOLD when within TP/SL bounds"
    
    print("[PASS] Strategy rotation and parameter optimization verified.\n")

def test_options_spread_logic():
    print("[TEST] Testing Options Spread selection, sizing, and TP/SL triggers...")
    
    # 1. Test Heuristic Sizing and recommendation
    market_state = {
        "btc_spot_price": 63000.0,
        "btc_perp_price": 63000.0,
        "btc_basis_spread_pct": 0.0,
        "btc_funding_apr": 0.0,
        "btc_volatility_annual": 0.40,
        "india_inflation_yoy": 3.0,
        "wallet_balance": 1000.0,
        "btc_close_history_100": [63000.0] * 100,
        "eth_close_history_100": [3000.0] * 100,
        "timestamp": 123456789.0,
        "consecutive_failures": {},
        "optimized_parameters": {}
    }
    
    kb = KnowledgeBase().load_historical_learnings()
    core = IntelligenceCore()
    
    decision = core.analyze_and_decide(market_state, kb, active_position=None)
    assert decision["recommended_strategy"] == "bull_call_spread"
    assert decision["action"] == "BUY"
    
    # 2. Test TP/SL exit triggers on options spread
    active_option_pos = {
        "is_option": True,
        "strategy": "bull_call_spread",
        "long_leg": {"symbol": "BTC-20260612-63000-C", "strike": 63000},
        "short_leg": {"symbol": "BTC-20260612-64400-C", "strike": 64400},
        "contracts": 10,
        "expiry": "2026-06-12",
        "initial_cost": 1.85,
        "entry_fees": 0.0006,
        "starting_capital": 100.0,
        "tp_target": 1.0,  # 1% of $100
        "sl_target": 2.0,  # 2% of $100
        "unrealized_pnl": 0.5
    }
    
    # Within bounds -> HOLD
    dec_hold = core.analyze_and_decide(market_state, kb, active_position=active_option_pos)
    assert dec_hold["action"] == "HOLD"
    
    # Breach TP target -> CLOSE
    active_option_pos["unrealized_pnl"] = 1.2
    dec_tp = core.analyze_and_decide(market_state, kb, active_position=active_option_pos)
    assert dec_tp["action"] == "CLOSE"
    
    # Breach SL target -> CLOSE
    active_option_pos["unrealized_pnl"] = -2.5
    dec_sl = core.analyze_and_decide(market_state, kb, active_position=active_option_pos)
    assert dec_sl["action"] == "CLOSE"
    
    # Test desk options methods mock returns
    desk = TradingDesk(use_sandbox=True)
    success, long_fill, short_fill, long_id, short_id = desk.open_options_spread("BTC-C", "BTC-C2", 10)
    assert success
    assert long_fill > 0
    assert short_fill > 0
    
    success, l_close, s_close = desk.close_options_spread("BTC-C", "BTC-C2", 10)
    assert success
    assert l_close > 0
    assert s_close > 0
    
    print("[PASS] Options spread logic and trading methods verified.\n")

def main():
    print("==================================================")
    print("RUNNING ANTIGRAVITY AI BRAIN VERIFICATION SUITE")
    print("==================================================")
    
    try:
        test_math_corpus()
        metrics_losing, metrics_winning = test_self_optimizer()
        market_state = test_market_sensor()
        learnings = test_knowledge_base()
        test_intelligence_core(market_state, learnings)
        test_trading_desk()
        test_strategy_rotation_and_optimization()
        test_options_spread_logic()
        
        print("==================================================")
        print("[SUCCESS] VERIFICATION PASSED")
        print("==================================================")
        sys.exit(0)
    except AssertionError as ae:
        print(f"\n[FAILURE] Assertion Error during verification: {ae}")
        sys.exit(1)
    except Exception as e:
        print(f"\n[FAILURE] Unexpected Error during verification: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
