# ai_brain_main.py
import os
import sys
import time
import json
import traceback
from datetime import datetime

# Ensure UTF-8 output
sys.stdout.reconfigure(encoding='utf-8')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

from market_sensor import MarketSensor
from knowledge_base import KnowledgeBase
from intelligence_core import IntelligenceCore
from trading_desk import TradingDesk
from self_optimizer import SelfOptimizer

STATE_FILE = os.path.join(BASE_DIR, "ai_brain_state.json")
LOG_FILE = os.path.join(BASE_DIR, "ai_brain.log")

def log_message(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    formatted = f"[{timestamp}] [BRAIN] {msg}"
    print(formatted)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(formatted + "\n")

def load_brain_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
                if "consecutive_failures" not in state:
                    state["consecutive_failures"] = {}
                if "optimized_parameters" not in state:
                    state["optimized_parameters"] = {}
                return state
        except Exception:
            pass
            
    # Default initial state
    return {
        "is_running": False,
        "pid": None,
        "active_position": None,
        "accumulated_profit_usd": 0.0,
        "trades": [],
        "consecutive_failures": {},
        "optimized_parameters": {},
        "last_update": datetime.now().isoformat()
    }

def sync_consecutive_failures(state):
    if "consecutive_failures" not in state:
        state["consecutive_failures"] = {}
    if "optimized_parameters" not in state:
        state["optimized_parameters"] = {}
        
    trades = state.get("trades", [])
    by_strat = {}
    for t in trades:
        strat = t.get("strategy")
        if strat:
            by_strat.setdefault(strat, []).append(t)
            
    for strat, strat_trades in by_strat.items():
        count = 0
        for t in strat_trades:
            if t.get("net_profit_usd", 0.0) <= 0.0:
                count += 1
            else:
                count = 0
        if strat not in state["consecutive_failures"]:
            state["consecutive_failures"][strat] = count % 3

def save_brain_state(state):
    state["last_update"] = datetime.now().isoformat()
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=4)
    except Exception as e:
        log_message(f"Error saving state file: {e}")

def is_pid_running(pid):
    if not pid:
        return False
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        try:
            import subprocess
            out = subprocess.check_output(
                ["tasklist", "/FI", f"PID eq {pid}"],
                shell=True,
                stderr=subprocess.DEVNULL
            )
            return str(pid) in out.decode("utf-8", errors="ignore")
        except Exception:
            return False

def select_bull_call_spread_legs(desk):
    log_message("Loading markets for strike selection...")
    try:
        markets = desk.exchange.load_markets()
    except Exception as e:
        log_message(f"Error loading markets: {e}")
        return None, None, None, None, None, None
        
    # Get current BTC price to determine strike levels
    perp_symbol = "BTC/USD:USD"
    try:
        ticker = desk.exchange.fetch_ticker(perp_symbol)
        btc_price = ticker.get('last') or ticker.get('close') or 63000.0
    except Exception as e:
        log_message(f"Error fetching ticker: {e}")
        return None, None, None, None, None, None
        
    # Find active Call options on BTC
    options = []
    for symbol, m in markets.items():
        if m.get('option') and (m.get('underlying') == 'BTC' or m.get('base') == 'BTC'):
            if m.get('optionType') == 'call':
                options.append(m)
                
    if not options:
        log_message("No Call options found on BTC.")
        return None, None, None, None, None, None
        
    # Sort options by expiry datetime, then by strike
    options = sorted(options, key=lambda x: (x.get('expiryDatetime', ''), x.get('strike', 0)))
    
    # Group by expiry to find the nearest expiry date
    expiries = sorted(list(set(o.get('expiryDatetime', '').split('T')[0] for o in options if o.get('expiryDatetime'))))
    
    # Choose nearest expiry that is in the future
    now_str = datetime.utcnow().strftime("%Y-%m-%d")
    target_expiry = None
    for exp in expiries:
        if exp >= now_str:
            target_expiry = exp
            break
            
    if not target_expiry:
        target_expiry = expiries[0]
        
    # Get all calls for this expiry
    expiry_calls = [o for o in options if o.get('expiryDatetime', '').startswith(target_expiry)]
    if not expiry_calls:
        log_message(f"No Call options found for target expiry {target_expiry}.")
        return None, None, None, None, None, None

    # Fetch tickers for all candidate call symbols to filter out disrupted ones
    symbols = [o['symbol'] for o in expiry_calls]
    try:
        tickers = desk.exchange.fetch_tickers(symbols)
    except Exception as e:
        log_message(f"Error fetching tickers for options filtering: {e}")
        return None, None, None, None, None, None

    valid_expiry_calls = []
    for o in expiry_calls:
        sym = o['symbol']
        t = tickers.get(sym, {})
        bid = t.get('bid')
        ask = t.get('ask')
        if bid is not None and ask is not None and bid < ask:
            valid_expiry_calls.append(o)

    if not valid_expiry_calls:
        log_message(f"No non-disrupted Call options found for target expiry {target_expiry}.")
        return None, None, None, None, None, None
        
    # Find ATM Call (closest to current BTC price) from valid calls
    valid_expiry_calls = sorted(valid_expiry_calls, key=lambda x: abs(x.get('strike', 0) - btc_price))
    atm_call = valid_expiry_calls[0]
    atm_strike = atm_call.get('strike')
    
    # Find OTM Call (higher strike than ATM) from valid calls
    otm_calls = [o for o in valid_expiry_calls if o.get('strike', 0) > atm_strike]
    if not otm_calls:
        log_message("No higher strike calls found.")
        return None, None, None, None, None, None
        
    # Pick strike that is approx $1,000 to $3,000 higher than ATM (target +$1,500)
    otm_calls_sorted = sorted(otm_calls, key=lambda x: abs(x.get('strike', 0) - (atm_strike + 1500.0)))
    otm_call = otm_calls_sorted[0]
    otm_strike = otm_call.get('strike')
    
    return atm_call['symbol'], otm_call['symbol'], atm_strike, otm_strike, target_expiry, btc_price

def keep_windows_awake():
    if sys.platform == "win32":
        try:
            import ctypes
            ES_CONTINUOUS = 0x80000000
            ES_SYSTEM_REQUIRED = 0x00000001
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
            log_message("[SYSTEM] Windows sleep/standby prevention activated.")
        except Exception as e:
            log_message(f"[SYSTEM] Failed to activate sleep prevention: {e}")

def restore_windows_sleep():
    if sys.platform == "win32":
        try:
            import ctypes
            ES_CONTINUOUS = 0x80000000
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            log_message("[SYSTEM] Windows sleep/standby prevention deactivated.")
        except Exception as e:
            log_message(f"[SYSTEM] Failed to deactivate sleep prevention: {e}")

def run_brain():
    state = load_brain_state()
    active_pid = state.get("pid")
    if active_pid and is_pid_running(active_pid) and active_pid != os.getpid():
        log_message(f"[ERROR] Another daemon process is already active under PID {active_pid}. Exiting.")
        sys.exit(f"Error: Daemon already active under PID {active_pid}")

    sync_consecutive_failures(state)
    state["pid"] = os.getpid()
    state["is_running"] = True
    save_brain_state(state)
    
    # Activate sleep prevention
    keep_windows_awake()

    log_message("==================================================")
    log_message(f"🧠 ANTIGRAVITY AI BRAIN INITIALIZED (PID: {os.getpid()})")
    log_message("==================================================")

    sensor = MarketSensor()
    kb = KnowledgeBase()
    core = IntelligenceCore()
    desk = TradingDesk()

    # Initial connection validation
    desk.check_connection()

    loop_count = 0
    try:
        while True:
            try:
                # Reload state config
                state = load_brain_state()
                if not state.get("is_running", False):
                    log_message("Stop signal received in state. Shutting down brain loop.")
                    break

                if state.get("pid") != os.getpid():
                    log_message(f"PID takeover detected (state PID: {state.get('pid')}, current PID: {os.getpid()}). Shutting down.")
                    break

                loop_count += 1
                log_message(f"--- Cycle #{loop_count} Ingestion & Reasoning ---")

                # 1. Sense the market
                market_state = sensor.fetch_live_indicators()
                wallet_bal = desk.get_wallet_balance()
                market_state["wallet_balance"] = wallet_bal
                
                # Inject failures and parameters for decision-making
                market_state["consecutive_failures"] = state.get("consecutive_failures", {})
                market_state["optimized_parameters"] = state.get("optimized_parameters", {})
                
                log_message(f"Ingested Market State | Wallet: ${wallet_bal:.2f} USD | Spot: ${market_state['btc_spot_price']} | Perp: ${market_state['btc_perp_price']} | Basis: {market_state['btc_basis_spread_pct']:+.4f}% | Funding: {market_state['btc_funding_apr']:.2f}% APR | Vol: {market_state['btc_volatility_annual']*100:.1f}%")

                # 1.5. Self-Healing State Reconciliation
                exchange_positions = desk.get_active_positions()
                symbol = "BTC/USD:USD"
                btc_pos_exchange = None
                for p in exchange_positions:
                    if p.get("symbol") == symbol:
                        btc_pos_exchange = p
                        break
                        
                local_pos = state.get("active_position")
                if local_pos is not None and not local_pos.get("is_option", False) and not desk.use_sandbox:
                    if btc_pos_exchange is None:
                        log_message(f"[WARN] State Reconciliation: Local state reports active position for {symbol}, but exchange reports none. Resetting active_position to None.")
                        state["active_position"] = None
                        save_brain_state(state)
                    else:
                        exch_qty = btc_pos_exchange.get("contracts", 1)
                        if local_pos.get("qty") != exch_qty:
                            log_message(f"[INFO] State Reconciliation: Syncing quantity from exchange: {local_pos.get('qty')} -> {exch_qty}")
                            local_pos["qty"] = exch_qty
                            state["active_position"] = local_pos
                            save_brain_state(state)
                elif local_pos is None and btc_pos_exchange is not None and not desk.use_sandbox:
                    log_message(f"[WARN] State Reconciliation: Orphan position detected on exchange for {symbol}. Executing emergency close order.")
                    exch_side = btc_pos_exchange.get("side", "buy").upper()
                    exit_side = "SELL" if exch_side in ["BUY", "LONG"] else "BUY"
                    desk.close_perp_position(symbol, exit_side, btc_pos_exchange.get("contracts"))

                # 2. Run Self-Optimization on completed trades history
                trades = state.get("trades", [])
                self_analysis = SelfOptimizer.analyze_performance(trades)
                state["self_analysis_metrics"] = self_analysis
                
                # Ingest learnings combining static backtests and live reflections
                historical_learnings = kb.load_historical_learnings(self_analysis)

                # 3. Consult Intelligence Core (Gemini / Heuristics)
                active_pos = state.get("active_position")
                
                # Check for options expiry and settle programmatically
                if active_pos is not None and active_pos.get("is_option", False):
                    expiry_str = active_pos.get("expiry")
                    if expiry_str:
                        try:
                            # Parse expiry (noon 12:00:00 PM UTC)
                            expiry_dt = datetime.strptime(f"{expiry_str} 12:00:00", "%Y-%m-%d %H:%M:%S")
                            now_utc = datetime.utcnow()
                            if now_utc >= expiry_dt:
                                log_message(f"[EXPIRY] Active options spread has expired (Expiry: {expiry_str} 12:00:00 UTC). Reconciling settlement...")
                                
                                settle_price = None
                                try:
                                    target_ts = int(expiry_dt.timestamp() * 1000)
                                    candles = desk.exchange.fetch_ohlcv("BTC/USD:USD", timeframe="1h", since=target_ts, limit=1)
                                    if candles:
                                        settle_price = float(candles[0][4])
                                except Exception as e:
                                    log_message(f"[EXPIRY] Error fetching historical settle price: {e}")
                                    
                                if settle_price is None:
                                    settle_price = float(market_state.get("btc_spot_price") or market_state.get("btc_perp_price") or 63000.0)
                                    
                                log_message(f"[EXPIRY] Settlement Price: ${settle_price:,.2f}")
                                
                                long_sym = active_pos["long_leg"]["symbol"]
                                short_sym = active_pos["short_leg"]["symbol"]
                                long_strike = active_pos["long_leg"]["strike"]
                                short_strike = active_pos["short_leg"]["strike"]
                                contracts = active_pos["contracts"]
                                initial_cost = active_pos["initial_cost"]
                                entry_fees = active_pos["entry_fees"]
                                
                                long_payoff = max(0.0, settle_price - long_strike)
                                short_payoff = max(0.0, settle_price - short_strike)
                                net_payoff = (long_payoff - short_payoff) * 0.001 * contracts
                                
                                exit_fees = (long_payoff + short_payoff) * 0.001 * contracts * 0.0003
                                net_profit = net_payoff - initial_cost - entry_fees - exit_fees
                                
                                trade_record = {
                                    "timestamp_entry": active_pos["entry_time"],
                                    "timestamp_exit": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    "strategy": active_pos["strategy"],
                                    "direction": "BUY",
                                    "qty": contracts,
                                    "entry_perp": initial_cost / (0.001 * contracts),
                                    "exit_perp": net_payoff / (0.001 * contracts) if net_payoff > 0 else 0.0,
                                    "fees_usd": entry_fees + exit_fees,
                                    "net_profit_usd": net_profit,
                                    "is_sandbox": active_pos["is_sandbox"],
                                    "exit_reason": "EXPIRY_SETTLEMENT"
                                }
                                
                                log_message(f"[EXPIRY] Spread Settled: Net Payoff: ${net_payoff:.4f} USD | Net Profit: ${net_profit:+.4f} USD")
                                
                                state = load_brain_state()
                                strat = active_pos["strategy"]
                                if "consecutive_failures" not in state:
                                    state["consecutive_failures"] = {}
                                if net_profit <= 0.0:
                                    state["consecutive_failures"][strat] = state["consecutive_failures"].get(strat, 0) + 1
                                else:
                                    state["consecutive_failures"][strat] = 0
                                    
                                state["trades"].append(trade_record)
                                state["accumulated_profit_usd"] += net_profit
                                state["active_position"] = None
                                save_brain_state(state)
                                
                                active_pos = None
                        except Exception as ex:
                            log_message(f"[EXPIRY] Error during expiry processing: {ex}")

                # Dynamic Unrealized PnL Injection
                if active_pos is not None:
                    if active_pos.get("is_option", False):
                        long_sym = active_pos["long_leg"]["symbol"]
                        short_sym = active_pos["short_leg"]["symbol"]
                        contracts = active_pos["contracts"]
                        initial_cost = active_pos["initial_cost"]
                        
                        try:
                            if desk.use_sandbox:
                                # In sandbox, simulate some profit over cycles
                                cycles = loop_count
                                current_value_usd = initial_cost + (cycles * 0.10)
                                exit_fees = (initial_cost * 2) * 0.0003
                                unrealized_pnl = current_value_usd - initial_cost - exit_fees
                            else:
                                tickers = desk.exchange.fetch_tickers([long_sym, short_sym])
                                long_ticker = tickers.get(long_sym, {})
                                short_ticker = tickers.get(short_sym, {})
                                
                                long_bid = long_ticker.get('bid') or long_ticker.get('last') or 0.0
                                short_ask = short_ticker.get('ask') or short_ticker.get('last') or 0.0
                                
                                current_value_usd = (long_bid - short_ask) * 0.001 * contracts
                                exit_fees = (long_bid + short_ask) * 0.001 * contracts * 0.0003
                                unrealized_pnl = current_value_usd - initial_cost - exit_fees
                        except Exception as e:
                            log_message(f"Error fetching options tickers for PnL: {e}")
                            unrealized_pnl = 0.0
                            
                        active_pos["unrealized_pnl"] = unrealized_pnl
                        log_message(f"Active Option Spread: Long {long_sym} / Short {short_sym} | Net PnL: {unrealized_pnl:+.4f} USD (TP: {active_pos['tp_target']:.4f}, SL: -{active_pos['sl_target']:.4f})")
                    else:
                        curr_perp_price = market_state.get("btc_perp_price") or market_state.get("btc_spot_price") or 60000.0
                        fill_p = active_pos.get("fill_price", curr_perp_price)
                        qty_cnt = active_pos.get("qty", 1)
                        direction = active_pos.get("direction", "BUY")
                        if direction == "BUY":
                            unrealized_pnl = qty_cnt * 0.001 * (curr_perp_price - fill_p)
                        else:
                            unrealized_pnl = qty_cnt * 0.001 * (fill_p - curr_perp_price)
                        active_pos["unrealized_pnl"] = unrealized_pnl
                        log_message(f"Active Position: {direction} {qty_cnt} contracts @ ${fill_p:,.2f} | Unrealized PnL: ${unrealized_pnl:+.4f} USD")

                decision = core.analyze_and_decide(market_state, historical_learnings, active_pos)
                
                # 3.5. Strategy Failure check and Failsafe Divert override
                rec_strat = decision.get("recommended_strategy")
                con_failures = state.get("consecutive_failures", {})
                
                just_failed = [s for s, c in con_failures.items() if c >= 3]
                
                if rec_strat in just_failed:
                    alternatives = ["triangular_arb", "stockfish_basis", "options_arb", "market_geometry"]
                    non_failed = [alt for alt in alternatives if alt != rec_strat and con_failures.get(alt, 0) < 3]
                    priority = ["triangular_arb", "stockfish_basis", "market_geometry", "options_arb"]
                    
                    new_strat = None
                    if non_failed:
                        strat_metrics = self_analysis.get("strategy_metrics", {})
                        best_score = -float('inf')
                        for alt in non_failed:
                            net_profit = strat_metrics.get(alt, {}).get("net_profit_usd", 0.0)
                            prio_score = -priority.index(alt) if alt in priority else -100
                            score = net_profit + prio_score * 0.01
                            if score > best_score:
                                best_score = score
                                best_alt = alt
                        new_strat = best_alt
                    else:
                        new_strat = "cash"
                        
                    log_message(f"[OVERRIDE] Strategy '{rec_strat}' has failed 3 times in a row. Diverting to '{new_strat}' to prevent further losses.")
                    decision["recommended_strategy"] = new_strat
                    decision["reasoning"] = f"[OVERRIDE] Diverting from failed '{rec_strat}' to '{new_strat}'. | " + decision.get("reasoning", "")
                    if new_strat == "cash":
                        decision["action"] = "CLOSE"
                        
                    # Optimize the failed strategy parameters immediately for later use
                    opt_params = state.setdefault("optimized_parameters", {})
                    strat_params = opt_params.setdefault(rec_strat, {
                        "min_profit_pct": 0.15,
                        "leverage": 10,
                        "timeframe": "15m"
                    })
                    
                    old_min_profit = strat_params.get("min_profit_pct", 0.15)
                    old_leverage = strat_params.get("leverage", 10)
                    old_timeframe = strat_params.get("timeframe", "15m")
                    
                    new_min_profit = min(old_min_profit + 0.05, 0.50)
                    new_leverage = max(old_leverage - 2, 2)
                    new_timeframe = "1h" if old_timeframe == "15m" else "4h" if old_timeframe == "1h" else "15m"
                    
                    strat_params["min_profit_pct"] = new_min_profit
                    strat_params["leverage"] = new_leverage
                    strat_params["timeframe"] = new_timeframe
                    
                    state["consecutive_failures"][rec_strat] = 0
                    log_message(f"[OPTIMIZE] Strategy '{rec_strat}' parameters optimized: min_profit_pct={new_min_profit:.2%}, leverage={new_leverage}x, timeframe={new_timeframe}. Resetting failure counter.")
                    save_brain_state(state)

                log_message(f"Regime: {decision.get('regime_classification')}")
                log_message(f"Reasoning Core: {decision.get('reasoning')}")
                log_message(f"Decision: Recommended Strategy={decision.get('recommended_strategy')} | Action={decision.get('action')} | Size=${decision.get('trade_size_usd')}")

                # Save indicators to state for visualization/analysis
                state["indicators"] = market_state
                state["last_thought"] = {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "reasoning": decision.get("reasoning"),
                    "regime": decision.get("regime_classification"),
                    "recommended_strategy": decision.get("recommended_strategy"),
                    "action": decision.get("action")
                }
                save_brain_state(state)

                # 4. Process Trading Action
                action = decision.get("action", "HOLD").upper()
                recommended_strategy = decision.get("recommended_strategy", "triangular_arb")
                trade_size = decision.get("trade_size_usd", 100.0)
                leverage = decision.get("leverage", 10)
                
                symbol = "BTC/USD:USD"

                if active_pos is None:
                    # Can open position
                    if recommended_strategy == "bull_call_spread":
                        if action in ["BUY", "SELL"]:
                            # Select options legs
                            if desk.use_sandbox:
                                long_symbol = "BTC-20260612-63000-C"
                                short_symbol = "BTC-20260612-64400-C"
                                long_strike = 63000
                                short_strike = 64400
                                expiry = "2026-06-12"
                                btc_price = 63000.0
                            else:
                                long_symbol, short_symbol, long_strike, short_strike, expiry, btc_price = select_bull_call_spread_legs(desk)
                                
                            if long_symbol and short_symbol:
                                contracts = 10
                                log_message(f"Executing Options Spread trade: BUY spread with {contracts} contracts. Long: {long_symbol}, Short: {short_symbol}")
                                try:
                                    success, long_fill, short_fill, long_id, short_id = desk.open_options_spread(long_symbol, short_symbol, contracts)
                                    if success:
                                        initial_cost = (long_fill - short_fill) * 0.001 * contracts
                                        entry_fees = (long_fill + short_fill) * 0.001 * contracts * 0.0003
                                        state = load_brain_state()
                                        state["active_position"] = {
                                            "is_option": True,
                                            "strategy": "bull_call_spread",
                                            "long_leg": {
                                                "symbol": long_symbol,
                                                "strike": long_strike,
                                                "order_id": long_id,
                                                "fill_price": long_fill
                                            },
                                            "short_leg": {
                                                "symbol": short_symbol,
                                                "strike": short_strike,
                                                "order_id": short_id,
                                                "fill_price": short_fill
                                            },
                                            "contracts": contracts,
                                            "expiry": expiry,
                                            "initial_cost": initial_cost,
                                            "entry_fees": entry_fees,
                                            "starting_capital": wallet_bal,
                                            "tp_target": wallet_bal * 0.005,
                                            "sl_target": wallet_bal * 0.01,
                                            "is_sandbox": desk.use_sandbox,
                                            "entry_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                        }
                                        save_brain_state(state)
                                except Exception as trade_err:
                                    log_message(f"[ERROR] Failed to execute options spread order: {trade_err}")
                                    state = load_brain_state()
                                    strat = "bull_call_spread"
                                    state["consecutive_failures"][strat] = state.get("consecutive_failures", {}).get(strat, 0) + 1
                                    save_brain_state(state)
                            else:
                                log_message("Failed to select option spread legs. Skipping entry.")
                    else:
                        if action in ["BUY", "SELL"]:
                            price = market_state["btc_perp_price"] or market_state["btc_spot_price"] or 60000.0
                            # Standard Delta contract size = 0.001 BTC
                            qty = trade_size / (0.001 * price)
                            qty_formatted = round(qty)
                            if qty_formatted < 1:
                                qty_formatted = 1
                                
                            log_message(f"Executing trade signal: {action} {qty_formatted} contracts...")
                            try:
                                success, fill_price, order_id = desk.open_perp_position(symbol, action, qty_formatted, leverage)
                                
                                if success:
                                    fill = fill_price or price
                                    state = load_brain_state()
                                    state["active_position"] = {
                                        "symbol": symbol,
                                        "strategy": recommended_strategy,
                                        "direction": action,
                                        "qty": qty_formatted,
                                        "fill_price": fill,
                                        "spot_entry_price": market_state["btc_spot_price"],
                                        "is_sandbox": desk.use_sandbox,
                                        "entry_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                    }
                                    save_brain_state(state)
                            except Exception as trade_err:
                                log_message(f"[ERROR] Failed to execute perp position order: {trade_err}")
                                state = load_brain_state()
                                state["consecutive_failures"][recommended_strategy] = state.get("consecutive_failures", {}).get(recommended_strategy, 0) + 1
                                save_brain_state(state)
                else:
                    # We have an active position
                    if action == "CLOSE" or (recommended_strategy == "cash"):
                        log_message(f"Executing exit signal. Closing current strategy: {active_pos['strategy']}...")
                        if active_pos.get("is_option", False):
                            # Close options spread
                            long_sym = active_pos["long_leg"]["symbol"]
                            short_sym = active_pos["short_leg"]["symbol"]
                            contracts = active_pos["contracts"]
                            initial_cost = active_pos["initial_cost"]
                            entry_fees = active_pos["entry_fees"]
                            
                            success, long_exit_price, short_exit_price = desk.close_options_spread(long_sym, short_sym, contracts)
                            if success:
                                # Calculate returns
                                final_value = (long_exit_price - short_exit_price) * 0.001 * contracts
                                exit_fees = (long_exit_price + short_exit_price) * 0.001 * contracts * 0.0003
                                total_fees = entry_fees + exit_fees
                                net_profit = final_value - initial_cost - total_fees
                                
                                trade_record = {
                                    "timestamp_entry": active_pos["entry_time"],
                                    "timestamp_exit": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    "strategy": active_pos["strategy"],
                                    "direction": "BUY",
                                    "qty": contracts,
                                    "entry_perp": initial_cost / (0.001 * contracts), # average entry premium
                                    "exit_perp": final_value / (0.001 * contracts), # average exit premium
                                    "fees_usd": total_fees,
                                    "net_profit_usd": net_profit,
                                    "is_sandbox": active_pos["is_sandbox"]
                                }
                                
                                log_message(f"Options Spread Closed. Net Profit: ${net_profit:+.4f} USD")
                                
                                state = load_brain_state()
                                if "consecutive_failures" not in state:
                                    state["consecutive_failures"] = {}
                                strat = active_pos["strategy"]
                                if net_profit <= 0.0:
                                    state["consecutive_failures"][strat] = state["consecutive_failures"].get(strat, 0) + 1
                                else:
                                    state["consecutive_failures"][strat] = 0
                                    
                                state["trades"].append(trade_record)
                                state["accumulated_profit_usd"] += net_profit
                                state["active_position"] = None
                                save_brain_state(state)
                        else:
                            # Standard perp close
                            exit_side = "SELL" if active_pos["direction"] == "BUY" else "BUY"
                            success, exit_price, order_id = desk.close_perp_position(symbol, exit_side, active_pos["qty"])
                            
                            if success:
                                close_price = exit_price or (market_state["btc_perp_price"] or market_state["btc_spot_price"] or 60000.0)
                                
                                # Calculate returns
                                entry = active_pos["fill_price"]
                                qty_cnt = active_pos["qty"]
                                # Profit = contracts * 0.001 * price_diff
                                if active_pos["direction"] == "BUY":
                                    gross_profit = (close_price - entry) * 0.001 * qty_cnt
                                else:
                                    gross_profit = (entry - close_price) * 0.001 * qty_cnt
                                    
                                # Roundtrip fee deduction
                                nominal_value = qty_cnt * 0.001 * entry
                                fees = nominal_value * 0.001 # 0.10% total fee
                                net_profit = gross_profit - fees
                                
                                trade_record = {
                                    "timestamp_entry": active_pos["entry_time"],
                                    "timestamp_exit": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    "strategy": active_pos["strategy"],
                                    "direction": active_pos["direction"],
                                    "qty": qty_cnt,
                                    "entry_perp": entry,
                                    "exit_perp": close_price,
                                    "fees_usd": fees,
                                    "net_profit_usd": net_profit,
                                    "is_sandbox": active_pos["is_sandbox"]
                                }
                                
                                log_message(f"Position Closed. Net Profit: ${net_profit:+.4f} USD")
                                
                                state = load_brain_state()
                                
                                # Initialize counters if not present
                                if "consecutive_failures" not in state:
                                    state["consecutive_failures"] = {}
                                if "optimized_parameters" not in state:
                                    state["optimized_parameters"] = {}
                                    
                                strat = active_pos["strategy"]
                                
                                # Update consecutive failures tracker
                                if net_profit <= 0.0:
                                    state["consecutive_failures"][strat] = state["consecutive_failures"].get(strat, 0) + 1
                                    log_message(f"Strategy '{strat}' trade failed to secure profit. Consecutive failures: {state['consecutive_failures'][strat]}/3")
                                    
                                    # Optimize if it hit 3 failures
                                    if state["consecutive_failures"][strat] >= 3:
                                        opt_params = state["optimized_parameters"].setdefault(strat, {
                                            "min_profit_pct": 0.15,
                                            "leverage": 10,
                                            "timeframe": "15m"
                                        })
                                        
                                        old_min_profit = opt_params.get("min_profit_pct", 0.15)
                                        old_leverage = opt_params.get("leverage", 10)
                                        old_timeframe = opt_params.get("timeframe", "15m")
                                        
                                        new_min_profit = min(old_min_profit + 0.05, 0.50)
                                        new_leverage = max(old_leverage - 2, 2)
                                        new_timeframe = "1h" if old_timeframe == "15m" else "4h" if old_timeframe == "1h" else "15m"
                                        
                                        opt_params["min_profit_pct"] = new_min_profit
                                        opt_params["leverage"] = new_leverage
                                        opt_params["timeframe"] = new_timeframe
                                        
                                        # Reset failure count so it can be used later
                                        state["consecutive_failures"][strat] = 0
                                        log_message(f"[OPTIMIZE] Strategy '{strat}' has failed 3 times in a row. Optimizing parameters: min_profit_pct={new_min_profit:.2%}, leverage={new_leverage}x, timeframe={new_timeframe}. Resetting failure counter.")
                                else:
                                    state["consecutive_failures"][strat] = 0
                                    log_message(f"Strategy '{strat}' secured profit of ${net_profit:+.4f} USD. Resetting failure counter.")
                                    
                                state["trades"].append(trade_record)
                                state["accumulated_profit_usd"] += net_profit
                                state["active_position"] = None
                                save_brain_state(state)
                            
                # Sleep loop checking stop signal
                steps = 30
                stop_detected = False
                for _ in range(steps):
                    if os.path.exists(STATE_FILE):
                        try:
                            with open(STATE_FILE, "r", encoding="utf-8") as f:
                                chk = json.load(f)
                                if not chk.get("is_running", False):
                                    stop_detected = True
                                    break
                        except Exception:
                            pass
                    time.sleep(1.0)
                    
                if stop_detected:
                    log_message("Orchestrator stop signal caught. Terminating.")
                    break

            except Exception as e:
                log_message(f"⚠️ Error in AI Brain daemon cycle: {e}")
                traceback.print_exc()
                time.sleep(10)
    except KeyboardInterrupt:
        log_message("AI Brain stopped manually (KeyboardInterrupt caught inside loop).")
    finally:
        # Print summary performance review report on shutdown
        state = load_brain_state()
        summary_report = SelfOptimizer.generate_shutdown_summary_report(state.get("trades", []))
        for line in summary_report.split("\n"):
            log_message(line)

        # Cleanup PID and deactivate sleep prevention
        restore_windows_sleep()
        state = load_brain_state()
        state["is_running"] = False
        state["pid"] = None
        save_brain_state(state)
        log_message("AI Brain Stopped successfully.")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ["--start", "--daemon"]:
        state = load_brain_state()
        active_pid = state.get("pid")
        if active_pid and is_pid_running(active_pid) and active_pid != os.getpid():
            print(f"[ERROR] AI Brain daemon is already running under PID {active_pid}. Exiting.")
            sys.exit(1)
        state["is_running"] = True
        save_brain_state(state)
        
    state = load_brain_state()
    if state.get("is_running", False):
        try:
            run_brain()
        except KeyboardInterrupt:
            log_message("AI Brain stopped manually.")
        finally:
            state = load_brain_state()
            if state.get("pid") == os.getpid():
                state["is_running"] = False
                state["pid"] = None
                save_brain_state(state)
