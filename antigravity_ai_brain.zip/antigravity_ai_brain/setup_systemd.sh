#!/bin/bash
# setup_systemd.sh - Configure Antigravity AI Brain as systemd service on Linux

set -e

if [ "$EUID" -ne 0 ]; then
  echo "[ERROR] Please run this script with sudo privileges (sudo ./setup_systemd.sh)."
  exit 1
fi

echo "=================================================="
echo "    SYSTEMD SERVICE CONFIGURATION SETUP"
echo "=================================================="

# Detect package manager
if command -v apt-get &> /dev/null; then
    apt-get update
    apt-get install -y python3 python3-pip python3-venv
elif command -v yum &> /dev/null; then
    yum install -y python3 python3-pip
fi

# Set up virtual environment
echo "[INFO] Configuring virtual environment..."
VENV_DIR="/opt/antigravity_ai_brain_env"
if [ ! -d "$VENV_DIR" ]; then
    python3 -m venv "$VENV_DIR"
fi

# Install dependencies in venv
echo "[INFO] Installing requirements in virtualenv..."
"$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install ccxt requests numpy psutil pandas yfinance

# Setup template .env if missing
CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$CURRENT_DIR/.env" ]; then
    echo "[INFO] Creating template .env file..."
    cat <<EOT > "$CURRENT_DIR/.env"
# Antigravity AI Brain Credentials Config
GEMINI_API_KEY=your_gemini_api_key_here
DELTA_API_KEY=your_delta_api_key_here
DELTA_API_SECRET=your_delta_api_secret_here
EOT
    echo "[WARN] Created template .env file in $CURRENT_DIR. Please edit this file before starting the service."
fi

# Create systemd service file
echo "[INFO] Creating systemd service file..."
cat <<EOT > /etc/systemd/system/aibrain.service
[Unit]
Description=Antigravity AI Brain Quant Trading Daemon
After=network.target

[Service]
Type=simple
User=$SUDO_USER
WorkingDirectory=$CURRENT_DIR
EnvironmentFile=$CURRENT_DIR/.env
ExecStart=$VENV_DIR/bin/python ai_brain_main.py --start
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOT

# Reload and enable service
echo "[INFO] Enabling systemd service..."
systemctl daemon-reload
systemctl enable aibrain

echo "=================================================="
echo "[SUCCESS] systemd service 'aibrain' configured!"
echo "- To start the daemon: sudo systemctl start aibrain"
echo "- To check status: sudo systemctl status aibrain"
echo "- To monitor logs: journalctl -u aibrain -f"
echo "- To stop daemon: sudo systemctl stop aibrain"
echo "=================================================="
